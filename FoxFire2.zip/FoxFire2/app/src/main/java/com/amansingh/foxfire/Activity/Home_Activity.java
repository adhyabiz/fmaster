package com.amansingh.foxfire.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.amansingh.foxfire.Adapters.HomeRecycler;
import com.amansingh.foxfire.Models.HomeListModel;
import com.amansingh.foxfire.R;

import java.util.ArrayList;

public class Home_Activity extends AppCompatActivity {

    private RecyclerView recyclerView;
    ArrayList<HomeListModel>aman=new ArrayList<>();
    HomeRecycler homeRecycler;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_);

        recyclerView=findViewById(R.id.recyclerView);
        button=findViewById(R.id.button);
        aman.clear();
        HomeListModel singh;
        singh=new HomeListModel("User 1","name","location");
        aman.add(singh);
        singh=new HomeListModel("2","name","locatin");
        aman.add(singh);
        homeRecycler=new HomeRecycler(aman,getApplicationContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(homeRecycler);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Home_Activity.this,Settings_Activity.class);
                startActivity(intent);
            }
        });
    }
}
